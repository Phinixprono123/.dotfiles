# Nordic theme for Zen browser
This is a sleek, mininmalistic zen browser theme inspired by the [Nord palette](https://www.nordtheme.com/).

